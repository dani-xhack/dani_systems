from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Lead, Ticket
from .forms import TicketForm
from .models import Lead, Ticket, Partner

def index(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        phone = request.POST.get('phone')
        if name and phone:
            Lead.objects.create(name=name, phone=phone)
            return redirect('/?success=1')
    
    return render(request, 'web/index.html')

@login_required
def cabinet(request):
    if hasattr(request.user, 'partner'):
        return redirect('partner_cabinet')
    if request.method == 'POST':
        form = TicketForm(request.POST)
        if form.is_valid():
            ticket = form.save(commit=False)
            ticket.user = request.user
            ticket.client_name = request.user.username
            ticket.save()
            return redirect('cabinet')
    else:
        form = TicketForm()

    tickets = Ticket.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'web/cabinet.html', {'tickets': tickets, 'form': form})

@login_required
def partner_cabinet(request):
    # Проверяем, является ли пользователь партнёром
    try:
        partner = request.user.partner
    except Partner.DoesNotExist:
        return redirect('cabinet') # Если не партнёр, кидаем в обычный ЛК

    # Берем заявки, назначенные этому партнёру
    tickets = Ticket.objects.filter(partner=partner).order_by('-created_at')
    return render(request, 'web/partner_cabinet.html', {'tickets': tickets})
