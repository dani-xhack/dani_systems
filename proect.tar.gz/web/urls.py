from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('cabinet/', views.cabinet, name='cabinet'),
    path('partner/', views.partner_cabinet, name='partner_cabinet'),
]
