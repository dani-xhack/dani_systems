from django.contrib import admin
from .models import Partner, Post, Review, Ticket, Joke

@admin.register(Partner)
class PartnerAdmin(admin.ModelAdmin):
    list_display = ('user', 'phone', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('user__username', 'phone')

@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ('title', 'created_at', 'is_published')
    list_filter = ('is_published',)
    search_fields = ('title', 'text')

@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('name', 'rating', 'is_published', 'created_at')
    list_filter = ('is_published', 'rating')
    search_fields = ('name', 'text')

@admin.register(Ticket)
class TicketAdmin(admin.ModelAdmin):
    list_display = ('subject', 'client_name', 'status', 'partner', 'time_spent', 'created_at')
    list_filter = ('status', 'priority', 'partner')
    search_fields = ('subject', 'client_name', 'phone')
    list_editable = ('status', 'partner')
    readonly_fields = ('user', 'created_at')

@admin.register(Joke)
class JokeAdmin(admin.ModelAdmin):
    list_display = ('name', 'text', 'is_published', 'created_at')
    list_filter = ('is_published',)
    search_fields = ('name', 'text')
